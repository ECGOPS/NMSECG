#!/bin/bash
echo "Starting Node.js deployment..."

# Install dependencies
npm install

# Start the application
npm start 