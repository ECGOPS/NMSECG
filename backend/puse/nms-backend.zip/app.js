console.log('Starting backend app.js...');
// Set NODE_ENV for development
process.env.NODE_ENV = process.env.NODE_ENV || 'development';
console.log('NODE_ENV:', process.env.NODE_ENV);

// Only load dotenv in development
if (process.env.NODE_ENV === 'development') {
  require('dotenv').config();
}

// Add error handling for missing environment variables
if (process.env.NODE_ENV === 'production') {
  const requiredEnvVars = [
    'AZURE_AD_AUDIENCE',
    'AZURE_AD_TENANT_ID', 
    'AZURE_AD_CLIENT_ID',
    'COSMOS_DB_ENDPOINT',
    'COSMOS_DB_KEY',
    'COSMOS_DB_DATABASE'
  ];
  
  const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
  if (missingVars.length > 0) {
    console.error('❌ Missing required environment variables:', missingVars);
    process.exit(1);
  } else {
    console.log('✅ All required environment variables are set');
  }
}

// Azure App Service Optimizations
if (process.env.NODE_ENV === 'production') {
  // Increase Node.js memory limit for Azure
  const v8 = require('v8');
  v8.setFlagsFromString('--max-old-space-size=2048'); // 2GB heap
  
  // Optimize garbage collection
  if (global.gc) {
    setInterval(() => {
      global.gc();
    }, 30000); // Run GC every 30 seconds
  }
  
  console.log('[AZURE] Memory optimization enabled');
  console.log('[AZURE] Heap size limit:', v8.getHeapStatistics().heap_size_limit / 1024 / 1024, 'MB');
}
const express = require('express');
const cors = require('cors');
const jwtCheck = require('./auth');
const { getUserRole } = require('./roles');
const checkJwt = require('./authMiddleware');
const { getContainer } = require('./cosmosClient');

const app = express();

// Trust proxy for Azure deployment (fixes rate limiting with X-Forwarded-For headers)
app.set('trust proxy', true);

// CORS configuration - ensure this runs BEFORE any other middleware
const corsOptions = {
  origin: [
    // Local development URLs
    'http://localhost:5173', 
    'https://localhost:5173', 
    'http://localhost:3000', 
    'https://localhost:3000',
    // Netlify domain - hardcoded for now
    'https://heroic-boba-b98a65.netlify.app',
    // ECG internal domain
    'http://proppvlap01.ecggh.com'
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  // Let cors reflect the request headers for preflight
  allowedHeaders: undefined,
  exposedHeaders: ['Content-Length', 'Content-Type', 'Cache-Control'],
  optionsSuccessStatus: 200
};

// Debug logging for CORS configuration
console.log('🔧 CORS Configuration:');
console.log('  NODE_ENV:', process.env.NODE_ENV);
console.log('  FRONTEND_URL:', process.env.FRONTEND_URL);
console.log('  NETLIFY_URL:', process.env.NETLIFY_URL);
console.log('  CORS Origins:', corsOptions.origin);

// Apply CORS middleware FIRST - before anything else
app.use(cors(corsOptions));

// Handle OPTIONS preflight requests BEFORE any other middleware
app.options('*', cors(corsOptions));

// Security middleware - add helmet for security headers
const helmet = require('helmet');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// Rate limiting for API protection - Increased limits for better user experience
const rateLimit = require('express-rate-limit');
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'production' ? 500 : 5000, // Increased: 500 in production, 5000 in development
  message: {
    error: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => process.env.NODE_ENV === 'development', // Skip rate limiting completely in development
  // Azure-specific configuration
  keyGenerator: (req) => {
    // Use X-Forwarded-For header if available (Azure proxy)
    return req.headers['x-forwarded-for'] || req.ip || req.connection.remoteAddress;
  }
});

// Apply rate limiting to all API routes
app.use('/api/', apiLimiter);

// More lenient rate limiting for high-traffic routes
const highTrafficLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'production' ? 1000 : 10000, // Very high limits for high-traffic routes
  message: {
    error: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => process.env.NODE_ENV === 'development', // Skip in development
  keyGenerator: (req) => {
    return req.headers['x-forwarded-for'] || req.ip || req.connection.remoteAddress;
  }
});

// Apply high-traffic rate limiting to specific routes that need it
app.use('/api/photos/', highTrafficLimiter);
app.use('/api/health', highTrafficLimiter);
app.use('/api/messages', highTrafficLimiter);
app.use('/api/broadcasts', highTrafficLimiter);

// Increase payload size limit for photo uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Security: Remove server information
app.disable('x-powered-by');

// Azure-specific configurations
if (process.env.NODE_ENV === 'production') {
  // Trust Azure's proxy headers
  app.set('trust proxy', true);
  
  // Log Azure-specific information
  console.log('[AZURE] Running in Azure production environment');
  console.log('[AZURE] Trust proxy enabled for X-Forwarded-For headers');
}

// Additional security headers for production
if (process.env.NODE_ENV === 'production') {
  app.use((req, res, next) => {
    // Remove or obfuscate headers that reveal API structure
    res.removeHeader('X-Powered-By');
    res.removeHeader('Server');
    
    // Add obfuscating headers
    res.setHeader('X-API-Version', 'v2');
    res.setHeader('X-Response-Time', Date.now().toString());
    
    // Log minimal information in production
    if (req.path.startsWith('/api/')) {
      console.log(`[API] ${req.method} ${req.path} - ${res.statusCode}`);
    }
    
    next();
  });
}

// Enhanced process management for Azure App Service
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  console.error('Stack trace:', err.stack);
  
  // In production, log the error and continue if possible
  if (process.env.NODE_ENV === 'production') {
    console.error('[AZURE] Critical error logged, attempting graceful shutdown');
    // Give time for logging before exit
    setTimeout(() => {
      process.exit(1);
    }, 1000);
  } else {
    process.exit(1);
  }
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
  
  // In production, log the error but don't crash
  if (process.env.NODE_ENV === 'production') {
    console.error('[AZURE] Unhandled rejection logged, continuing operation');
  }
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('🔄 SIGTERM received, starting graceful shutdown...');
  if (server) {
    server.close(() => {
      console.log('✅ HTTP server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
});

process.on('SIGINT', () => {
  console.log('🔄 SIGINT received, starting graceful shutdown...');
  if (server) {
    server.close(() => {
      console.log('✅ HTTP server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
});

// Memory monitoring for Azure
if (process.env.NODE_ENV === 'production') {
  setInterval(() => {
    const memUsage = process.memoryUsage();
    const memUsageMB = {
      rss: Math.round(memUsage.rss / 1024 / 1024),
      heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024),
      heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024),
      external: Math.round(memUsage.external / 1024 / 1024)
    };
    
    if (memUsageMB.heapUsed > 1500) { // Alert if heap usage > 1.5GB
      console.warn('[AZURE] High memory usage detected:', memUsageMB);
    }
    
    if (process.env.LOG_MEMORY === 'true') {
      console.log('[AZURE] Memory usage:', memUsageMB);
    }
  }, 60000); // Check every minute
}

// Health check endpoint - must be defined before JWT middleware
app.get('/', (req, res) => {
  // Fast health check for Azure App Service
  const startTime = Date.now();
  
  res.json({ 
    status: 'API is running',
    environment: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: {
      used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024)
    },
    responseTime: Date.now() - startTime
  });
});

// Dedicated health check endpoint for Azure App Service
app.get('/api/health', (req, res) => {
  const startTime = Date.now();
  
  // Minimal health check - just return status
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    responseTime: Date.now() - startTime
  });
});

// Azure AD JWT authentication for all routes - ENABLED for production and development testing
if (process.env.NODE_ENV === 'production' || process.env.TEST_JWT === 'true') {
  console.log('[SECURITY] ENABLING JWT authentication for production/testing');
  console.log('[DEBUG] Environment variables:', {
    NODE_ENV: process.env.NODE_ENV,
    TEST_JWT: process.env.TEST_JWT,
    AZURE_AD_AUDIENCE: process.env.AZURE_AD_AUDIENCE,
    AZURE_AD_TENANT_ID: process.env.AZURE_AD_TENANT_ID
  });
  
  // Apply JWT authentication to all routes EXCEPT health check and photo routes (public access needed)
  app.use((req, res, next) => {
    // Allow CORS preflight without auth
    if (req.method === 'OPTIONS') {
      return next();
    }
    
    // Skip JWT authentication for health check endpoint
    if (req.path === '/api/health') {
      console.log('[SECURITY] Skipping JWT for health check route:', req.path);
      return next();
    }
    
    // Skip JWT authentication for photo routes (public access needed)
    if (req.path.startsWith('/api/photos/serve/') ||
        req.path.startsWith('/api/photos/upload') ||
        req.path.startsWith('/api/photos/upload-file') ||
        req.path.startsWith('/api/photos/delete')) {
      console.log('[SECURITY] Skipping JWT for photo route:', req.path);
      return next();
    }
    
    // Apply JWT authentication to all other routes
    jwtCheck(req, res, next);
  });
  
  console.log('[SECURITY] JWT Authentication: ENABLED (with photo serve exclusion)');
} else {
  console.log('[DEV] JWT authentication disabled for development');
  console.log('[DEV] JWT Authentication: DISABLED');
  console.log('[DEV] To enable JWT testing, set TEST_JWT=true');
}

// Global error handling middleware - MUST be placed here to catch JWT errors
app.use((err, req, res, next) => {
  console.error('Global error handler caught:', err);
  
  // Handle JWT authentication errors specifically
  if (err.status === 401 || err.statusCode === 401) {
    console.log('[ERROR] JWT Authentication failed:', err.message);
    return res.status(401).json({ 
      error: 'Unauthorized',
      message: 'Authentication required',
      details: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
  
  // Handle other errors
  if (process.env.NODE_ENV === 'production') {
    res.status(500).json({ 
      error: 'Internal server error',
      message: 'An unexpected error occurred'
    });
  } else {
    res.status(500).json({ 
      error: err.message,
      stack: err.stack
    });
  }
});

// Production-ready user authentication middleware
app.use(async (req, res, next) => {
  try {
    // Skip authentication for health check endpoint and photo routes
    if (req.path === '/' || 
        req.path === '/api/health' ||
        req.path.startsWith('/api/photos/serve/') ||
        req.path.startsWith('/api/photos/upload') ||
        req.path.startsWith('/api/photos/upload-file') ||
        req.path.startsWith('/api/photos/delete')) {
      return next();
    }
    
    let userData = null;
    
    if (process.env.NODE_ENV === 'production' || process.env.TEST_JWT === 'true') {
      // Production/Testing: Use JWT token for authentication
      console.log('[AUTH] Checking JWT authentication...');
      console.log('[AUTH] req.auth:', req.auth);
      console.log('[AUTH] req.auth.payload.sub:', req.auth?.payload?.sub);
      console.log('[AUTH] req.auth.payload.oid:', req.auth?.payload?.oid);
      console.log('[AUTH] Authorization header:', req.headers.authorization ? 'Present' : 'Missing');
      
      const tokenUserId = (req.auth?.payload?.oid) || (req.auth?.payload?.sub);
      if (tokenUserId) {
        try {
          const { CosmosClient } = require('@azure/cosmos');
          const client = new CosmosClient({ 
            endpoint: process.env.COSMOS_DB_ENDPOINT, 
            key: process.env.COSMOS_DB_KEY 
          });
          const database = client.database(process.env.COSMOS_DB_DATABASE);
          const container = database.container('users');
          
          // 1. First try to find user by JWT UID
          let { resources } = await container.items.query({
            query: 'SELECT * FROM c WHERE c.uid = @uid',
            parameters: [{ name: '@uid', value: tokenUserId }]
          }).fetchAll();
          
          if (resources.length > 0) {
            // User found by JWT UID - use existing user
            userData = resources[0];
            if (process.env.NODE_ENV === 'production') {
              console.log(`[AUTH] User authenticated: ${userData.id}`);
            } else {
              console.log(`[AUTH] Found user in database:`, { id: userData.id, role: userData.role });
            }
          } else {
            // 2. Try to find user by email (for existing users)
            const jwtEmail = (req.auth?.payload?.email || req.auth?.payload?.preferred_username || '').toLowerCase();
            const { resources: emailUsers } = await container.items.query({
              query: 'SELECT * FROM c WHERE LOWER(c.email) = @email',
              parameters: [{ name: '@email', value: jwtEmail }]
            }).fetchAll();
            
            if (emailUsers.length > 0) {
              // Found existing user by email - update their UID to match JWT and apply smart name mapping
              const existingUser = emailUsers[0];
              
              // Smart name mapping: use Azure AD name if it's more complete
              const azureName = req.auth.payload.name || req.auth.payload.preferred_username;
              const existingName = existingUser.name || existingUser.displayName;
              
              // Get name mapping strategy from environment (default to 'app_first')
              const nameMappingStrategy = process.env.NAME_MAPPING_STRATEGY || 'app_first';
              let finalName = existingName;
              let nameChanged = false;
              
              if (azureName && existingName) {
                switch (nameMappingStrategy) {
                  case 'app_first':
                    // Always use app name if it exists
                    finalName = existingName;
                    if (azureName !== existingName) {
                      console.log(`[AUTH] Name mismatch: App="${existingName}" vs Azure="${azureName}" - using app name`);
                    }
                    break;
                    
                  case 'azure_first':
                    // Use Azure AD name if different from app name
                    if (azureName !== existingName) {
                      console.log(`[AUTH] Updating name from "${existingName}" to "${azureName}"`);
                      finalName = azureName;
                      nameChanged = true;
                    }
                    break;
                    
                  case 'app_only':
                    // Only use app name, never Azure AD
                    finalName = existingName;
                    break;
                    
                  case 'azure_only':
                    // Only use Azure AD name, never app name
                    if (azureName !== existingName) {
                      console.log(`[AUTH] Forcing name update from "${existingName}" to "${azureName}"`);
                      finalName = azureName;
                      nameChanged = true;
                    }
                    break;
                    
                  default:
                    // Default to app_first
                    finalName = existingName;
                    break;
                }
              } else {
                // Fallback to whichever name is available
                finalName = existingName || azureName;
              }
              
              // For existing users, we need to recreate with new ID since Cosmos DB ID is immutable
              // Only set pre_registered status if user was previously pre_registered or has no status
              // Existing users with active status should remain active
              const needsApproval = existingUser.status === 'pre_registered' || !existingUser.status;
              
              const newUserData = {
                id: tokenUserId, // Prefer stable oid if available
                uid: tokenUserId,
                name: finalName,
                displayName: finalName,
                email: jwtEmail || existingUser.email,
                role: existingUser.role, // Keep original role
                status: needsApproval ? 'pre_registered' : (existingUser.status || 'active'), // Preserve existing status or default to active
                region: existingUser.region || '',
                district: existingUser.district || '',
                staffId: existingUser.staffId || '',
                disabled: existingUser.disabled || false,
                createdAt: existingUser.createdAt, // Keep original creation date
                updatedAt: new Date().toISOString()
              };
              
              // Delete old user and create new one with correct ID
              await container.item(existingUser.id, existingUser.id).delete();
              await container.items.create(newUserData);
              userData = newUserData;
              console.log(`[AUTH] Migrated existing user to new ID: ${existingUser.email} (old ID: ${existingUser.id} → new ID: ${tokenUserId})`);
            } else {
              // 3. Create new user with pending role and pre_registered status
              userData = {
                id: tokenUserId,
                uid: tokenUserId,
                email: (req.auth?.payload?.email || req.auth?.payload?.preferred_username),
                name: (req.auth?.payload?.name || req.auth?.payload?.preferred_username),
                displayName: (req.auth?.payload?.name || req.auth?.payload?.preferred_username),
                role: 'pending', // New users start with pending role
                status: 'pre_registered', // New status for pending approval
                region: '',
                district: '',
                staffId: '',
                disabled: false,
                createdAt: new Date().toISOString(),
              };
              
              // Create new user
              await container.items.create(userData);
              if (process.env.NODE_ENV === 'production') {
                console.log(`[AUTH] Created new user: ${userData.id}`);
              } else {
                console.log(`[AUTH] Created new user from JWT:`, { id: userData.id, email: userData.email, role: userData.role, status: userData.status });
              }
            }
          }
        } catch (error) {
          console.error(`[AUTH] Error fetching/creating user:`, error.message);
          return res.status(500).json({ error: 'Authentication failed' });
        }
      } else {
        // Require valid JWT token in production/testing
        console.log('[AUTH] ❌ No valid JWT token provided - authentication required');
        console.log('[AUTH] req.auth is:', req.auth);
        console.log('[AUTH] req.auth.payload.sub is:', req.auth?.payload?.sub);
        console.log('[AUTH] Authorization header is:', req.headers.authorization);
        return res.status(401).json({ error: 'No valid JWT token provided' });
      }
    } else {
      // Development: Use query parameter authentication (existing logic)
      if (req.query.userId) {
        try {
          const { CosmosClient } = require('@azure/cosmos');
          const client = new CosmosClient({ 
            endpoint: process.env.COSMOS_DB_ENDPOINT, 
            key: process.env.COSMOS_DB_KEY 
          });
          const database = client.database(process.env.COSMOS_DB_DATABASE);
          const container = database.container('users');
          
          const { resources } = await container.items.query(`SELECT * FROM c WHERE c.id = "${req.query.userId}"`).fetchAll();
          if (resources.length > 0) {
            userData = resources[0];
            if (process.env.NODE_ENV === 'production') {
              console.log(`[AUTH] User authenticated: ${userData.id}`);
            } else {
              console.log(`[AUTH] Found user in database:`, userData);
            }
          }
        } catch (error) {
          console.log(`[AUTH] Error fetching user from database:`, error.message);
        }
      }
      
      // If no user found, use default for development
      if (!userData) {
        userData = {
          id: req.query.userId || 'dev-user-id',
          role: 'system_admin', // Default to system admin for development
          region: '',
          district: '',
          email: 'dev@example.com'
        };
        if (process.env.NODE_ENV === 'production') {
          console.log(`[DEV] Using development user: ${userData.id}`);
        } else {
          console.log(`[DEV] Using default user:`, userData);
        }
      }
    }
    
    req.userRole = userData.role;
    // Prefer stable Azure AD oid, then sub, then database id
    req.userId = (req.auth?.payload?.oid) || (req.auth?.payload?.sub) || userData.id;
    req.user = userData;
    
    next();
  } catch (err) {
    console.error('Error getting user role:', err);
    res.status(500).json({ error: 'Failed to get user role' });
  }
});

// Routers for all collections
const collections = [
  'broadcastMessages', 'chat_messages', 'controlOutages', 'devices', 'districts', 'feeders',
  'loadMonitoring', 'music_files', 'op5Faults', 'overheadLineInspections', 'permissions', 'regions',
  'securityEvents', 'sms_logs', 'staffIds', 'substationInspections', 'system', 'userLogs',
  'users', 'vitAssets', 'vitInspections'
];

collections.forEach(col => {
  app.use(`/api/${col}`, require(`./routes/${col}`));
});

// Production obfuscated endpoint mappings
if (process.env.NODE_ENV === 'production') {
  // Obfuscated routes for production
  app.use('/api/audio', require('./routes/music_files'));
  app.use('/api/employees', require('./routes/staffIds'));
  app.use('/api/accounts', require('./routes/users'));
  app.use('/api/zones', require('./routes/regions'));
  app.use('/api/areas', require('./routes/districts'));
  app.use('/api/inspections', require('./routes/overheadLineInspections'));
  app.use('/api/assets', require('./routes/vitAssets'));
  app.use('/api/checks', require('./routes/vitInspections'));
  app.use('/api/outages', require('./routes/controlOutages'));
  app.use('/api/monitoring', require('./routes/loadMonitoring'));
  app.use('/api/faults', require('./routes/op5Faults'));
  app.use('/api/events', require('./routes/securityEvents'));
  app.use('/api/substations', require('./routes/substationInspections'));
  app.use('/api/logs', require('./routes/userLogs'));
  app.use('/api/core', require('./routes/system'));
  app.use('/api/access', require('./routes/permissions'));
  app.use('/api/broadcasts', require('./routes/broadcastMessages'));
  app.use('/api/messages', require('./routes/chat_messages'));
  app.use('/api/equipment', require('./routes/devices'));
  app.use('/api/powerlines', require('./routes/feeders'));
  app.use('/api/notifications', require('./routes/sms_logs'));
}

// Photo routes (NO AUTH REQUIRED)
app.use('/api/photos', require('./routes/photos'));

// Health check route (NO AUTH REQUIRED)
app.use('/api/health', require('./routes/health'));

// Add a protected test route
app.get('/api/protected', checkJwt, async (req, res) => {
  try {
    const container = getContainer();
    // Fetch a single item as a test (replace with your actual query logic)
    const { resources } = await container.items.query('SELECT TOP 1 * FROM c').fetchAll();
    res.json({
      message: 'Access granted. This is protected data from Cosmos DB!',
      data: resources[0] || null,
      user: req.user
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch from Cosmos DB', details: err.message });
  }
});

// Redirect /api/logs to /api/userLogs for compatibility
app.use('/api/logs', require('./routes/userLogs'));

// Development test route - bypass authentication
if (process.env.NODE_ENV === 'development') {
  app.get('/api/test', (req, res) => {
    res.json({ 
      message: 'Development test route working',
      user: req.user,
      userRole: req.userRole,
      timestamp: new Date().toISOString()
    });
  });
}

// Error handling middleware moved to after JWT middleware for proper JWT error handling

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Create HTTP server for WebSocket support
const http = require('http');
const server = http.createServer(app);

// Initialize WebSocket server
const WebSocketServer = require('./websocket/WebSocketServer');
const wsServer = new WebSocketServer(server);

// Make WebSocket server available to routes
app.set('wsServer', wsServer);

const PORT = process.env.PORT || 3001;

// Azure App Service startup optimization
const startupTime = Date.now();

server.listen(PORT, () => {
  const startupDuration = Date.now() - startupTime;
  
  if (process.env.NODE_ENV === 'production') {
    console.log(`✅ Server started successfully in ${startupDuration}ms`);
    console.log(`🔒 Security: JWT Authentication ENABLED`);
    console.log(`🔗 WebSocket server ready for connections`);
    console.log(`🌐 Azure App Service optimized configuration loaded`);
    console.log(`📊 Memory limit: ${Math.round(require('v8').getHeapStatistics().heap_size_limit / 1024 / 1024)}MB`);
    
    // Log Azure-specific startup info
    console.log(`[AZURE] Process ID: ${process.pid}`);
    console.log(`[AZURE] Node version: ${process.version}`);
    console.log(`[AZURE] Platform: ${process.platform}`);
    console.log(`[AZURE] Architecture: ${process.arch}`);
  } else if (process.env.TEST_JWT === 'true') {
    console.log(`Backend running on port ${PORT} in ${startupDuration}ms`);
    console.log(`Environment: ${process.env.NODE_ENV}`);
    console.log(`JWT Authentication: ENABLED`);
    console.log(`🔗 WebSocket server ready for connections`);
  } else {
    console.log(`Backend running on port ${PORT} in ${startupDuration}ms`);
    console.log(`Environment: ${process.env.NODE_ENV}`);
    console.log(`JWT Authentication: DISABLED`);
    console.log(`🔗 WebSocket server ready for connections`);
  }
});

// Azure App Service keep-alive optimization
if (process.env.NODE_ENV === 'production') {
  // Keep the process alive and handle Azure App Service recycling
  setInterval(() => {
    // Log health status every 5 minutes
    const memUsage = process.memoryUsage();
    console.log(`[AZURE] Health check - Memory: ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB, Uptime: ${Math.round(process.uptime())}s`);
  }, 300000); // 5 minutes
} 