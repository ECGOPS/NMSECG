# Azure App Service Optimization Guide

This guide explains the optimizations made to resolve the Azure App Service issues you were experiencing:

- **Thread pool starvation** (heartbeat taking 8+ seconds)
- **Process exit errors** (unexpected crashes)
- **Long startup time** (100+ seconds)

## 🚀 Optimizations Implemented

### 1. Enhanced Web.config
- **IISNode Configuration**: Optimized Node.js process management
- **Health Check Settings**: Proper health check configuration for Azure
- **Performance Headers**: Security and performance headers
- **Compression**: Enabled gzip compression for better performance

### 2. IISNode Configuration (iisnode.yml)
- **Process Management**: Increased concurrent request limits
- **Memory Optimization**: Better buffer management
- **Graceful Shutdown**: Proper process termination handling
- **Health Check Path**: Dedicated health endpoint configuration

### 3. Application Optimizations (app.js)
- **Memory Management**: Increased heap size to 2GB
- **Garbage Collection**: Automatic GC every 30 seconds
- **Process Monitoring**: Enhanced error handling and logging
- **Graceful Shutdown**: Proper SIGTERM/SIGINT handling
- **Azure-Specific Logging**: Detailed Azure environment information

### 4. Startup Script (startup.js)
- **Module Preloading**: Preloads critical modules for faster startup
- **Thread Pool Optimization**: Increased UV_THREADPOOL_SIZE to 64
- **Memory Flags**: Sets proper Node.js memory flags

### 5. Azure Configuration (.azure/config)
- **Startup Command**: Uses optimized startup script
- **Environment Variables**: Production-optimized settings
- **Health Check**: Proper health check configuration
- **Always On**: Prevents app unloading

## 📁 Files Modified/Created

```
backend/
├── web.config                    # Enhanced IIS configuration
├── iisnode.yml                   # IISNode optimization settings
├── startup.js                    # Azure-optimized startup script
├── .azure/config                 # Azure App Service settings
├── deploy-azure-optimized.ps1   # Deployment script
├── app.js                        # Enhanced with Azure optimizations
└── package.json                  # Updated scripts
```

## 🚀 Deployment Instructions

### Option 1: Using the Deployment Script (Recommended)

1. **Update the script parameters** in `deploy-azure-optimized.ps1`:
   ```powershell
   param(
       [string]$ResourceGroupName = "your-actual-resource-group",
       [string]$AppServiceName = "your-actual-app-service-name",
       [string]$DeploymentSlot = "production"
   )
   ```

2. **Run the deployment script**:
   ```powershell
   .\deploy-azure-optimized.ps1
   ```

### Option 2: Manual Deployment

1. **Create deployment package**:
   ```powershell
   Compress-Archive -Path @("app.js", "startup.js", "package.json", "web.config", "iisnode.yml", ".azure/config", "routes/", "websocket/", "auth.js", "authMiddleware.js", "cosmosClient.js", "roles.js") -DestinationPath "nms-backend-optimized.zip"
   ```

2. **Deploy to Azure**:
   ```bash
   az webapp deployment source config-zip --resource-group YOUR_RESOURCE_GROUP --name YOUR_APP_SERVICE --src nms-backend-optimized.zip
   ```

## ⚙️ Azure App Service Configuration

After deployment, ensure these settings in Azure Portal:

### Application Settings
```
NODE_ENV = production
NODE_OPTIONS = --max-old-space-size=2048 --expose-gc
UV_THREADPOOL_SIZE = 64
```

### Configuration
- **Always On**: Enabled
- **Web Sockets**: Enabled
- **HTTP Version**: 2.0
- **Min TLS Version**: 1.2

### Health Check
- **Path**: `/api/health`
- **Interval**: 30 seconds
- **Timeout**: 10 seconds

## 🔍 Monitoring and Verification

### 1. Check Health Endpoint
```bash
curl https://your-app.azurewebsites.net/api/health
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2025-08-12T08:35:00.000Z",
  "uptime": 300,
  "responseTime": 5
}
```

### 2. Monitor Logs
- **Azure Portal**: App Service → Logs → Log stream
- **Application Insights**: If enabled, check performance metrics

### 3. Performance Metrics
- **Response Time**: Should be < 100ms for health checks
- **Memory Usage**: Should be < 1.5GB
- **Startup Time**: Should be < 30 seconds

## 🐛 Troubleshooting

### Common Issues

1. **App Still Taking Long to Start**
   - Check if `startup.js` is being used
   - Verify environment variables are set
   - Check Azure App Service logs

2. **Memory Issues**
   - Verify `NODE_OPTIONS` includes `--max-old-space-size=2048`
   - Check if garbage collection is enabled
   - Monitor memory usage in logs

3. **Health Check Failures**
   - Verify `/api/health` endpoint is accessible
   - Check if JWT middleware is bypassing health checks
   - Verify CORS configuration

### Debug Commands

```bash
# Check app status
az webapp show --resource-group YOUR_RESOURCE_GROUP --name YOUR_APP_SERVICE

# View logs
az webapp log tail --resource-group YOUR_RESOURCE_GROUP --name YOUR_APP_SERVICE

# Restart app
az webapp restart --resource-group YOUR_RESOURCE_GROUP --name YOUR_APP_SERVICE
```

## 📊 Expected Improvements

After implementing these optimizations:

- **Startup Time**: 100+ seconds → < 30 seconds
- **Health Check Response**: 8+ seconds → < 100ms
- **Process Stability**: Fewer crashes and unexpected exits
- **Memory Usage**: Better memory management and GC
- **Overall Performance**: Faster response times and better reliability

## 🔄 Maintenance

### Regular Monitoring
- Check Azure App Service metrics weekly
- Monitor memory usage and response times
- Review logs for any new issues

### Updates
- Keep Node.js version updated
- Monitor dependency updates
- Test optimizations in staging environment first

## 📞 Support

If you continue to experience issues:

1. Check Azure App Service logs first
2. Verify all configuration files are properly deployed
3. Test health endpoint manually
4. Review memory usage and performance metrics
5. Consider enabling Application Insights for detailed monitoring

---

**Note**: These optimizations are specifically designed for Azure App Service. If deploying to other platforms, some configurations may need adjustment.
