require('dotenv').config();
const { CosmosClient } = require('@azure/cosmos');

async function main() {
  const emailArg = process.argv[2] || process.env.EMAIL;
  if (!emailArg) {
    console.error('Usage: node check-user-by-email.js <email>');
    process.exit(1);
  }

  const endpoint = process.env.COSMOS_DB_ENDPOINT;
  const key = process.env.COSMOS_DB_KEY;
  const databaseId = process.env.COSMOS_DB_DATABASE;
  const containerId = 'users';

  if (!endpoint || !key || !databaseId) {
    console.error('Missing Cosmos DB env vars. Ensure COSMOS_DB_ENDPOINT, COSMOS_DB_KEY, COSMOS_DB_DATABASE are set.');
    process.exit(1);
  }

  const client = new CosmosClient({ endpoint, key });
  const container = client.database(databaseId).container(containerId);

  try {
    console.log(`Looking up user by email: ${emailArg}`);
    const query = {
      query: 'SELECT * FROM c WHERE c.email = @email',
      parameters: [{ name: '@email', value: emailArg }]
    };
    const { resources } = await container.items.query(query).fetchAll();

    if (!resources || resources.length === 0) {
      console.log('User not found');
      return;
    }

    const user = resources[0];
    console.log('User found:');
    console.log(JSON.stringify({
      id: user.id,
      uid: user.uid,
      email: user.email,
      name: user.name,
      displayName: user.displayName,
      role: user.role,
      status: user.status,
      region: user.region,
      district: user.district,
      staffId: user.staffId,
      disabled: user.disabled,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt
    }, null, 2));
  } catch (err) {
    console.error('Error querying user:', err.message);
    process.exit(1);
  }
}

main();
