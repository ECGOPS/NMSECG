# Azure App Service Deployment Script - Optimized Version
# This script deploys the optimized backend to Azure App Service

param(
    [string]$ResourceGroupName = "your-resource-group",
    [string]$AppServiceName = "your-app-service-name",
    [string]$DeploymentSlot = "production"
)

Write-Host "🚀 Starting Azure App Service deployment..." -ForegroundColor Green

# Check if Azure CLI is installed
try {
    $azVersion = az version --output json | ConvertFrom-Json
    Write-Host "✅ Azure CLI version: $($azVersion.'azure-cli')" -ForegroundColor Green
} catch {
    Write-Host "❌ Azure CLI not found. Please install it first." -ForegroundColor Red
    exit 1
}

# Check if logged in to Azure
try {
    $account = az account show --output json | ConvertFrom-Json
    Write-Host "✅ Logged in as: $($account.user.name)" -ForegroundColor Green
} catch {
    Write-Host "❌ Not logged in to Azure. Please run 'az login' first." -ForegroundColor Red
    exit 1
}

# Create deployment package
Write-Host "📦 Creating deployment package..." -ForegroundColor Yellow

# Remove existing package if it exists
if (Test-Path "nms-backend-optimized.zip") {
    Remove-Item "nms-backend-optimized.zip" -Force
}

# Create optimized deployment package
$compressParams = @{
    Path = @(
        "app.js",
        "startup.js", 
        "package.json",
        "web.config",
        "iisnode.yml",
        ".azure/config",
        "routes/",
        "websocket/",
        "auth.js",
        "authMiddleware.js",
        "cosmosClient.js",
        "roles.js"
    )
    CompressionLevel = "Optimal"
    DestinationPath = "nms-backend-optimized.zip"
}

Compress-Archive @compressParams

Write-Host "✅ Deployment package created: nms-backend-optimized.zip" -ForegroundColor Green

# Deploy to Azure App Service
Write-Host "🚀 Deploying to Azure App Service..." -ForegroundColor Yellow

try {
    if ($DeploymentSlot -eq "production") {
        az webapp deployment source config-zip `
            --resource-group $ResourceGroupName `
            --name $AppServiceName `
            --src "nms-backend-optimized.zip"
    } else {
        az webapp deployment source config-zip `
            --resource-group $ResourceGroupName `
            --name $AppServiceName `
            --slot $DeploymentSlot `
            --src "nms-backend-optimized.zip"
    }
    
    Write-Host "✅ Deployment completed successfully!" -ForegroundColor Green
    
    # Get the app URL
    $appUrl = az webapp show --resource-group $ResourceGroupName --name $AppServiceName --query "defaultHostName" --output tsv
    Write-Host "🌐 Your app is available at: https://$appUrl" -ForegroundColor Cyan
    
    # Test the health endpoint
    Write-Host "🔍 Testing health endpoint..." -ForegroundColor Yellow
    Start-Sleep -Seconds 10 # Wait for app to start
    
    try {
        $healthResponse = Invoke-RestMethod -Uri "https://$appUrl/api/health" -Method Get -TimeoutSec 30
        Write-Host "✅ Health check passed: $($healthResponse.status)" -ForegroundColor Green
    } catch {
        Write-Host "⚠️ Health check failed. The app may still be starting up." -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "❌ Deployment failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Clean up
Write-Host "🧹 Cleaning up..." -ForegroundColor Yellow
if (Test-Path "nms-backend-optimized.zip") {
    Remove-Item "nms-backend-optimized.zip" -Force
}

Write-Host "🎉 Deployment process completed!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. Monitor the app logs in Azure Portal" -ForegroundColor White
Write-Host "2. Check the health endpoint: https://$appUrl/api/health" -ForegroundColor White
Write-Host "3. Monitor performance metrics in Azure Portal" -ForegroundColor White
