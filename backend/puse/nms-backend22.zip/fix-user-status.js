const { CosmosClient } = require('@azure/cosmos');

// Load environment variables
require('dotenv').config();

const endpoint = process.env.COSMOS_DB_ENDPOINT;
const key = process.env.COSMOS_DB_KEY;
const databaseId = process.env.COSMOS_DB_DATABASE;

if (!endpoint || !key || !databaseId) {
  console.error('❌ Missing required environment variables:');
  console.error('- COSMOS_DB_ENDPOINT:', endpoint ? 'Set' : 'Missing');
  console.error('- COSMOS_DB_KEY:', key ? 'Set' : 'Missing');
  console.error('- COSMOS_DB_DATABASE:', databaseId ? 'Set' : 'Missing');
  process.exit(1);
}

const client = new CosmosClient({ endpoint, key });
const database = client.database(databaseId);
const container = database.container('users');

async function fixUserStatus() {
  try {
    console.log('🔧 Starting user status fix...');
    
    // Find all users with pre_registered status
    const { resources: preRegisteredUsers } = await container.items.query(
      `SELECT * FROM c WHERE c.status = 'pre_registered'`
    ).fetchAll();
    
    console.log(`Found ${preRegisteredUsers.length} users with pre_registered status`);
    
    if (preRegisteredUsers.length === 0) {
      console.log('✅ No users with pre_registered status found');
      return;
    }
    
    let fixedCount = 0;
    let skippedCount = 0;
    
    for (const user of preRegisteredUsers) {
      console.log(`\n👤 Processing user: ${user.email || user.name} (ID: ${user.id})`);
      console.log(`   Current status: ${user.status}`);
      console.log(`   Current role: ${user.role}`);
      console.log(`   Created at: ${user.createdAt}`);
      console.log(`   Updated at: ${user.updatedAt || 'Not set'}`);
      
      // Check if user should be active
      // Users with system_admin, global_engineer, or other approved roles should be active
      const shouldBeActive = user.role && user.role !== 'pending' && user.role !== 'pre_registered';
      
      if (shouldBeActive) {
        console.log(`   ✅ User has approved role (${user.role}), setting status to 'active'`);
        
        // Update user status to active
        const updatedUser = {
          ...user,
          status: 'active',
          updatedAt: new Date().toISOString()
        };
        
        await container.item(user.id, user.id).replace(updatedUser);
        fixedCount++;
        console.log(`   ✅ Status updated to 'active'`);
      } else {
        console.log(`   ⚠️  User has pending role (${user.role}), keeping pre_registered status`);
        skippedCount++;
      }
    }
    
    console.log(`\n📊 Summary:`);
    console.log(`   ✅ Fixed: ${fixedCount} users`);
    console.log(`   ⚠️  Skipped: ${skippedCount} users (still pending)`);
    console.log(`   📝 Total processed: ${preRegisteredUsers.length} users`);
    
  } catch (error) {
    console.error('❌ Error fixing user status:', error);
    process.exit(1);
  }
}

// Run the fix
fixUserStatus().then(() => {
  console.log('\n✅ User status fix completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
