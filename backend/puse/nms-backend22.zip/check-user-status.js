const { CosmosClient } = require('@azure/cosmos');

// Load environment variables
require('dotenv').config();

const endpoint = process.env.COSMOS_DB_ENDPOINT;
const key = process.env.COSMOS_DB_KEY;
const databaseId = process.env.COSMOS_DB_DATABASE;

if (!endpoint || !key || !databaseId) {
  console.error('❌ Missing required environment variables:');
  console.error('- COSMOS_DB_ENDPOINT:', endpoint ? 'Set' : 'Missing');
  console.error('- COSMOS_DB_KEY:', key ? 'Set' : 'Missing');
  console.error('- COSMOS_DB_DATABASE:', databaseId ? 'Set' : 'Missing');
  process.exit(1);
}

const client = new CosmosClient({ endpoint, key });
const database = client.database(databaseId);
const container = database.container('users');

async function checkUserStatus() {
  try {
    console.log('🔍 Checking user status...');
    
    // Find the specific user by email
    const { resources: users } = await container.items.query(
      `SELECT * FROM c WHERE c.email = "afiifi@qna336.onmicrosoft.com"`
    ).fetchAll();
    
    if (users.length === 0) {
      console.log('❌ User with email afiifi@qna336.onmicrosoft.com not found');
      return;
    }
    
    const user = users[0];
    console.log(`\n👤 User Details:`);
    console.log(`   Email: ${user.email}`);
    console.log(`   ID: ${user.id}`);
    console.log(`   Name: ${user.name || 'Not set'}`);
    console.log(`   Display Name: ${user.displayName || 'Not set'}`);
    console.log(`   Status: ${user.status || 'Not set'}`);
    console.log(`   Role: ${user.role || 'Not set'}`);
    console.log(`   Region: ${user.region || 'Not set'}`);
    console.log(`   District: ${user.district || 'Not set'}`);
    console.log(`   Staff ID: ${user.staffId || 'Not set'}`);
    console.log(`   Disabled: ${user.disabled || false}`);
    console.log(`   Created at: ${user.createdAt || 'Not set'}`);
    console.log(`   Updated at: ${user.updatedAt || 'Not set'}`);
    
    // Check if user can access the system
    const canAccess = user.status === 'active' && user.role && user.role !== 'pending' && user.role !== 'pre_registered';
    console.log(`\n🔐 Access Status:`);
    console.log(`   Can access system: ${canAccess ? '✅ Yes' : '❌ No'}`);
    
    if (!canAccess) {
      console.log(`   Reason: ${user.status !== 'active' ? `Status is '${user.status}'` : `Role is '${user.role}'`}`);
    }
    
  } catch (error) {
    console.error('❌ Error checking user status:', error);
    process.exit(1);
  }
}

// Run the check
checkUserStatus().then(() => {
  console.log('\n✅ User status check completed');
  process.exit(0);
}).catch((error) => {
  console.error('❌ Script failed:', error);
  process.exit(1);
});
